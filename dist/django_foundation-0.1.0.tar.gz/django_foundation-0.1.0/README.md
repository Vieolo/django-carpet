# Django Foundation 0.1.0

This package contains the universally used functionalities for Django projects

```text
Note: This package requires python 3.11 and higher
```

## Installation
```text
pip install git+ssh://git@GitHub.com/vieolo/django-foundation.git
```

## Import
```python

```
